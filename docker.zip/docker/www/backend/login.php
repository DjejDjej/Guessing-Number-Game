<?php
session_start();
require_once 'db.php';

// Enable error reporting
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // username and password sent from form
    $myusername = mysqli_real_escape_string($conn, $_POST['username']);
    $mypassword = $_POST['password'];  // No need to escape passwords, as we will hash them

    // SQL to fetch the user with the username
    $sql = "SELECT id, password FROM users WHERE username = '$myusername'";
    $result = $conn->query($sql);
    $row = $result->fetch_assoc();

    // If username is found
    if ($row) {
        if (password_verify($mypassword, $row['password'])) {
            // Set session variables
            $_SESSION['login_user'] = $myusername;

            // Redirect to user dashboard or homepage
            header("location: /index.html");
            exit();
        } else {
            header("location: /login.html?error=invalid_credentials");
            exit();
        }
    } else {
        header("location: /login.html?error=invalid_credentials");
        exit();
    }
}
?>