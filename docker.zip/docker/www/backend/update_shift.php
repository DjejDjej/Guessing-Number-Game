<?php
// update_shift.php
require_once 'db.php';

$id = $_POST['id'];
$updateFields = [];

foreach ($_POST as $key => $value) {
    if ($key !== 'id') {
        $updateFields[] = "$key='" . $conn->real_escape_string($value) . "'";
    }
}

$updateQuery = "UPDATE shifts SET " . implode(", ", $updateFields) . " WHERE id=" . $conn->real_escape_string($id);

$response = ['success' => false];

if ($conn->query($updateQuery) === TRUE) {
    $response['success'] = true;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>