<?php
// update_entry.php
session_start();
require_once 'db.php';

if (!isset($_SESSION['login_user'])) {
    die(json_encode(['error' => 'User not logged in']));
}

$username = $_SESSION['login_user'];

// Check if the user is an admin
$sql = "SELECT admin FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    die(json_encode(['error' => 'Unauthorized']));
}

$id = $_POST['id'];
$updateFields = [];

foreach ($_POST as $key => $value) {
    if ($key !== 'id') {
        $updateFields[] = "$key='" . $conn->real_escape_string($value) . "'";
    }
}

$updateQuery = "UPDATE fronta SET " . implode(", ", $updateFields) . " WHERE id=" . $conn->real_escape_string($id);

$response = ['success' => false];

if ($conn->query($updateQuery) === TRUE) {
    $response['success'] = true;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>