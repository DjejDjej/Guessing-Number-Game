<?php
// get_shifts.php
session_start();
require_once 'db.php';

if (!isset($_SESSION['login_user'])) {
    die(json_encode(['error' => 'User not logged in']));
}

$username = $_SESSION['login_user'];

// Check if the user is an admin
$sql = "SELECT admin FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$isAdmin = $user['admin'] == 1;

// Fetch shifts from the database
$sql = "SELECT * FROM shifts";
$result = $conn->query($sql);

$shifts = array();

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $shifts[] = $row;
    }
}

$conn->close();

$response = [
    'shifts' => $shifts,
    'isAdmin' => $isAdmin
];

header('Content-Type: application/json');
echo json_encode($response);
?>