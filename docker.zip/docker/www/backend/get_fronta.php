<?php
// get_fronta.php
session_start();
require_once 'db.php'; // Ensure db.php connects to the correct database (fronta)

if (!isset($_SESSION['login_user'])) {
    die(json_encode(['error' => 'User not logged in']));
}

$username = $_SESSION['login_user'];

// Check if the user is an admin
$sql = "SELECT admin FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

$isAdmin = $user['admin'] == 1;

// Fetch data from the fronta table
$sql = "SELECT * FROM fronta";
$result = $conn->query($sql);

$frontaData = array();

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $frontaData[] = $row;
    }
}

$conn->close();

$response = [
    'frontaData' => $frontaData,
    'isAdmin' => $isAdmin
];

header('Content-Type: application/json');
echo json_encode($response);
?>