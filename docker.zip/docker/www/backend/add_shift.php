<?php
// add_shift.php
require_once 'db.php';

$shift = [];
foreach ($_POST as $key => $value) {
    $shift[$key] = $conn->real_escape_string($value);
}

$columns = implode(", ", array_keys($shift));
$values = "'" . implode("', '", array_values($shift)) . "'";

$insertQuery = "INSERT INTO shifts ($columns) VALUES ($values)";

$response = ['success' => false];

if ($conn->query($insertQuery) === TRUE) {
    $response['success'] = true;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>