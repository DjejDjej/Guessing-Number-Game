<?php
// delete_shift.php
require_once 'db.php';

$id = $_POST['id'];
$response = ['success' => false];

$deleteQuery = "DELETE FROM shifts WHERE id=" . $conn->real_escape_string($id);

if ($conn->query($deleteQuery) === TRUE) {
    $response['success'] = true;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>