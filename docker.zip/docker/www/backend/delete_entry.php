<?php
// delete_entry.php
session_start();
require_once 'db.php';

if (!isset($_SESSION['login_user'])) {
    die(json_encode(['error' => 'User not logged in']));
}

$username = $_SESSION['login_user'];

// Check if the user is an admin
$sql = "SELECT admin FROM users WHERE username = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $username);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($user['admin'] != 1) {
    die(json_encode(['error' => 'Unauthorized']));
}

$id = $_POST['id'];
$response = ['success' => false];

$deleteQuery = "DELETE FROM fronta WHERE id=" . $conn->real_escape_string($id);

if ($conn->query($deleteQuery) === TRUE) {
    $response['success'] = true;
}

$conn->close();

header('Content-Type: application/json');
echo json_encode($response);
?>
