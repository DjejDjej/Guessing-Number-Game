<?php
require_once 'db.php';

$message = '';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = mysqli_real_escape_string($conn, $_POST['username']);
    $password = mysqli_real_escape_string($conn, $_POST['password']);
    $hashed_password = password_hash($password, PASSWORD_DEFAULT); // Hashing the password

    // SQL to check if the username already exists
    $check_sql = "SELECT id FROM users WHERE username = '$username'";
    $result = $conn->query($check_sql);

    if ($result->num_rows > 0) {
        // Username already exists
        header("Location: ../register.html?error=username_taken");
        exit();
    } else {
        // SQL to insert new user
        $insert_sql = "INSERT INTO users (username, password) VALUES ('$username', '$hashed_password')";
        if ($conn->query($insert_sql) === TRUE) {
            header("Location: ../login.html");
            exit();
        } else {
            $message = "Error: " . $insert_sql . "<br>" . $conn->error;
        }
    }
}
echo $message;
?>