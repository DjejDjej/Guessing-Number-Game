<?php
session_start();

$response = array();

// Check if the user is logged in
if (isset($_SESSION['login_user'])) {
    // User is logged in
    $response['loggedIn'] = true;
    $response['username'] = htmlspecialchars($_SESSION['login_user']);
} else {
    // User is not logged in
    $response['loggedIn'] = false;
}

// Return the response in JSON format
header('Content-Type: application/json');
echo json_encode($response);
?>