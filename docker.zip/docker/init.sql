-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Server version: 5.7.44
-- PHP version: 8.2.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

-- Database creation
CREATE DATABASE IF NOT EXISTS crmDB DEFAULT CHARACTER SET utf16 COLLATE utf16_czech_ci;
USE crmDB;

-- Table creation: fronta
CREATE TABLE IF NOT EXISTS fronta (
  id int(11) NOT NULL AUTO_INCREMENT,
  fronta varchar(255) COLLATE utf16_czech_ci NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_czech_ci;

-- Table creation: shifts
CREATE TABLE IF NOT EXISTS shifts (
  id int(11) NOT NULL AUTO_INCREMENT,
  shift_value tinyint(5) NOT NULL DEFAULT '8',
  shift_date date DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_czech_ci;

-- Table creation: users
CREATE TABLE IF NOT EXISTS users (
  id int(255) NOT NULL AUTO_INCREMENT,
  username varchar(50) COLLATE utf16_czech_ci NOT NULL,
  password varchar(255) COLLATE utf16_czech_ci NOT NULL,
  admin tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf16 COLLATE=utf16_czech_ci;

INSERT INTO `users` (`id`, `username`, `password`, `admin`) VALUES
(1, 'admin', '$2y$10$ONBmvfLe5WDel5gynbDkbekSh4CToTh8bB1rBBV8NAqDTjJyJYQDG', 1);


COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
